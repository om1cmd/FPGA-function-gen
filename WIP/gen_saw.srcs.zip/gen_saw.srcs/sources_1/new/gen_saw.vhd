-------------------------------------------------
--! @brief N-bit synchronous up counter with enable
--! @version 1.4
--! @copyright (c) 2019-2026 Tomas Fryza, MIT license
--!
--! This design implements a parameterizable N-bit
--! binary up counter with synchronous, high-active
--! reset and clock enable input. The counter wraps
--! around to zero after reaching its maximum value
--! (2^G_BITS - 1).
--
-- Notes:
-- - Synchronous design (rising edge of clk)
-- - High-active synchronous reset
-- - Enable input controls counting
-- - Modulo 2^N operation (automatic wrap-around)
-- - Integer-based internal counter
-------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;  -- Package for data types conversion

-------------------------------------------------

entity gen_saw is
    generic (
        G_BITS : positive := 7  --! Default number of bits
    );
    port (
        clk : in  std_logic;                             --! Main clock
        rst : in  std_logic;                             --! High-active synchronous reset
        en  : in  std_logic;                             --! Clock enable input
        cnt : out std_logic_vector(G_BITS - 1 downto 0)  --! Counter value
        
    );
end entity gen_saw;

-------------------------------------------------

architecture behavioral of gen_saw is

    -- Maximum counter value = 2^G_BITS - 1
    constant C_MAX : integer := 2**G_BITS - 1;
    constant C_1 : integer := 2**G_BITS - 20;
    constant C_2 : integer := 2**G_BITS - 14;
    constant C_3 : integer := 2**G_BITS - 7;
    constant C_4 : integer := 2**G_BITS - 1;

    -- Integer counter with defined range
    signal sig_cnt : integer range 0 to C_MAX;

begin

    --! Clocked process with synchronous reset which implements
    --! N-bit up counter.

    p_counter : process (clk) is
    begin
        if rising_edge(clk) then
            if rst = '1' then    -- Synchronous, active-high reset
                sig_cnt <= 0;

            elsif en = '1' and per_bit = '00'then  -- Clock enable activated
                if sig_cnt = C_1 then
                    sig_cnt <= 0;
                else
                    sig_cnt <= sig_cnt + 1;
                end if;          -- Each `if` must end by `end if`
            elsif en = '1' and per_bit = '01'then  -- Clock enable activated
                if sig_cnt = C_2 then
                    sig_cnt <= 0;
                else
                    sig_cnt <= sig_cnt + 1;
                end if;
            elsif en = '1' and per_bit = '10'then  -- Clock enable activated
                if sig_cnt = C_3 then
                    sig_cnt <= 0;
                else
                    sig_cnt <= sig_cnt + 1;
                end if;          -- Each `if` must end by `end if`
            elsif en = '1' and per_bit = '11'then  -- Clock enable activated
                if sig_cnt = C_4 then
                    sig_cnt <= 0;
                else
                    sig_cnt <= sig_cnt + 1;
                end if;
            end if;
        end if;
    end process p_counter;

    -- Convert integer to std_logic_vector
    cnt <= std_logic_vector(to_unsigned(sig_cnt, G_BITS));

end architecture behavioral;