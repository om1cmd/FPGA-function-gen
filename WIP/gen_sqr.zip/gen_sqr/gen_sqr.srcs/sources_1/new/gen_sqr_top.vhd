----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
----------------------------------------------------------------------------------

entity gen_sqr_top is
    Port ( rst : in STD_LOGIC;
           en : in STD_LOGIC;
           per_bit : in STD_LOGIC_VECTOR (3 downto 0);
           clk : in STD_LOGIC;
           bin: in STD_LOGIC_VECTOR (3 downto 0);
           dac_out: out STD_LOGIC_VECTOR (7 downto 0);
end gen_sqr_top;

architecture Behavioral of gen_sqr_top is
    -- Component declaration for clock enable
    component clk_en is
        generic (
            G_MAX : positive
        );
        port (
            clk : in  std_logic;
            rst : in  std_logic;
            ce  : out std_logic
        );
    end component clk_en;
    
    component gen_sqr is
    port (
           clk : in STD_LOGIC;
           rst : in STD_LOGIC;
           per_bit : in unsigned (3 downto 0);
           dac_out : out STD_LOGIC_VECTOR (7 downto 0)
    );
    end component gen_sqr;

begin
    -- Component instantiation of clock enable for 10 ms
    clock_0 : component clk_en
        generic map (
            G_MAX => 10_000_000
        )
        port map (
            clk => clk,
            rst => btnu,
            ce  => sig_en_10ms
        );
        
     
        
        
      
        
end architecture behavioral;
