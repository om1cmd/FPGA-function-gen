----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/05/2026 03:21:01 PM
-- Design Name: 
-- Module Name: clk_en - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity clk_en is
    generic(
        G_MAX : positive :=4_000_000 -- Default value
    );
    Port ( clk : in STD_LOGIC;
           rst : in STD_LOGIC;
           ce : out STD_LOGIC);
end clk_en;

architecture Behavioral of clk_en is
    signal s_cnt : integer range 0 to G_MAX-1;
begin

-- Count clock pulses and generate a one-clock-cycle enable pulse
    process (clk) is
    begin
        if rising_edge(clk) then  -- Synchronous process
            if rst = '1' then     -- High-active reset
                ce      <= '0';   -- Reset output
                s_cnt <= 0;     -- Reset internal counter

            elsif s_cnt = G_MAX-1 then
                -- TODO: Set output pulse and reset internal counter
                ce <= '1';
                s_cnt <= 0;
                
            else
                -- TODO: Clear output and increment internal counter
                ce <= '0';
                s_cnt <= s_cnt + 1;
                
            end if;  -- End if for reset/check
        end if;      -- End if for rising_edge
    end process;

end Behavioral;
