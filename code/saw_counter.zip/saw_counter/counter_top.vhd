----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/05/2026 04:10:35 PM
-- Design Name: 
-- Module Name: counter_top - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity counter_top is
    Port ( clk : in STD_LOGIC;
           btnu : in STD_LOGIC;
           led : out STD_LOGIC_VECTOR (7 downto 0));
end counter_top;

architecture Behavioral of counter_top is

-- Component declaration for clock enable
    component clk_en is
        generic (
            G_MAX : positive
        );
        port (
            clk : in  std_logic;
            rst : in  std_logic;
            ce  : out std_logic
        );
    end component clk_en;

    -- Component declaration for binary counter
    component counter is
        generic (
        G_BITS : positive --! Default number of bits
    );
    port (
        clk : in  std_logic;                             --! Main clock
        rst : in  std_logic;                             --! High-active synchronous reset
        en  : in  std_logic;                             --! Clock enable input
        cnt : out std_logic_vector(G_BITS - 1 downto 0)  --! Counter value
    );
    end component counter;

    -- Internal signal for counter
    signal sig_en_10ms : std_logic;

begin

    -- Component instantiation of clock enable for 10 ms
    clock_0 : component clk_en
        generic map (
            G_MAX => 15_000_000
        )
        port map (
            clk => clk,
            rst => btnu,
            ce  => sig_en_10ms
        );

    -- Component instantiation of 8-bit binary counter
        eightbit : component counter
        generic map (
            G_BITS => 8
    
        )
        port map (
            clk => clk,
            rst => btnu,
            en => sig_en_10ms,
            cnt => led(7 downto 0)
            

         );

end architecture behavioral;
